from __future__ import annotations

from base.folders import folder, block_config
import applib
import base.functions as func
from base.MusicPlayer import MusicPlayer
from base.cursors import Cursor

from PyQt6.QtWidgets import QGraphicsItem
from PyQt6.QtWidgets import QGraphicsPolygonItem, QGraphicsItemGroup
from PyQt6.QtGui import QPolygonF, QColor, QBrush, QPen
from PyQt6.QtCore import Qt, QPointF

from components.SceneObject import SceneObject, Cell, Size
from components.Clickable import Clickable
from components.Rotatable import Rotatable

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from world.World import World

@func.safe_class
class Block(SceneObject):
    save = ("name",)
    def __init__(self, w:World, cell:Cell, name:str):
        if cell.x >= w.size.w or cell.y >= w.size.h or cell.x < 0 or cell.y < 0:
            self.exists = False
            folder.log.write(f"Block <{name}(x:{cell.x}, y:{cell.y})> Located behind the world", type="BlockData")

        integrity = block_config[name].get("integrity", 1)
        self.pixmap = func.get_texture(name if block_config[name].get("texture") is None else block_config[name].get("texture"))
        self.shadow_item = None

        super().__init__(w, cell, Size(self.pixmap.width()//32, self.pixmap.height()//32), name, integrity)
    
    def draw(self):
        if self.exists and self.w.scene is not None:
            self.pixmap_item = self.w.scene.addPixmap(self.pixmap)

            if block_config[self.name]["z"] >= 20:
                const = (self.size.w+self.size.h)*2.5
                polygon = QPolygonF([
                    QPointF(0, self.size.h*32),
                    QPointF(0, 0),
                    QPointF(self.size.w*32, 0),
                    QPointF(self.size.w*32+const, const),
                    QPointF(self.size.w*32+const, self.size.h*32+const),
                    QPointF(const, self.size.h*32+const)])

                self.shadow_item = QPolygonF(polygon)
                self.shadow_item.translate(self.cell.x * 32, self.cell.y * 32)
                self.w.shadow_layer.add(self.shadow_item)

            if block_config[self.name].get("centered", False):
                self.pixmap_item.setPos((self.cell.x-(self.size[0]/4))*32, (self.cell.y-(self.size[1]/4))*32)
            else:
                self.pixmap_item.setPos(self.cell.x*32, self.cell.y*32)
            self.pixmap_item.setZValue(block_config[self.name]["z"])  
            self.pixmap_item.setTransformOriginPoint((self.size[0]/2)*32, (self.size[1]/2)*32)
            self.pixmap_item.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)

            if Rotatable in self.components:
                self.pixmap_item.setRotation(self.components[Rotatable].value)

            if Clickable in self.components:
                self.pixmap_item.setCursor(Cursor.Hand)

    def finish(self):
        if hasattr(self, "pixmap_item"):
            folder.log.write("Block was placed 2 times", type=applib.ERROR)
            return
        
        for cell in self.get_occupied_cells():
            blocks = self.w.block_map.get(cell)
            if blocks is None:
                continue
            for block in blocks:
                if block is self or block_config[block.name]["z"] < 20:
                    continue
                return
            
        self.draw()
        MusicPlayer.play("place", volume=0.7)
        self.w.append_block(self)

    def remove(self):
        if not self.exists:
            return
        self.exists = False

        if self.shadow_item is not None:
            self.w.shadow_layer.remove(self.shadow_item)
            
        self.w.remove_block(self)

    def info(self):
            output = ""
            for name, value in self.__dict__.items():
                output += f"{name}: {value}, "
            return f"<{type(self).__name__}({output[:-2]})>"

    def __repr__(self):
        return f"<{type(self).__name__}>"