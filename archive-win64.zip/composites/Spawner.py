


class Spawner:
    ...